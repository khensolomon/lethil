declare module "scriptive" {
  namespace scriptive {
      /**
       * run command line.
       */
      function command(): Promise<any>;
      /**
       * start server.
       */
      function server(): Promise<any>;
      // interface PlatformPath {}
  }
  // const scriptive: scriptive.PlatformPath;

  export = scriptive;
}
